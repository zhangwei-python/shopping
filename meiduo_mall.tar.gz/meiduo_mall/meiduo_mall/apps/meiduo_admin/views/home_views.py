"""
主页视图实现
"""

from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from users.models import User

from rest_framework.permissions import IsAdminUser

class UserTotalCountView(APIView):

    permission_classes = [IsAdminUser]

    def get(self, request):
        # 1、统计出用户数量
        count = User.objects.count()

        # 根据Django配置中的TIME_ZONE来获取指定时区的当前时刻
        cur_time = timezone.localtime()

        # 2、构建响应
        return Response({
            'count': count,
            # 'date': <当日> —— 本地当前
            'date': cur_time.date()
        })


class UserDayCountView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        # 需求：过滤出今日新建的用户数量
        # 1、查询的目标数据是：User模型类
        # 2、一直条件：今日的0时刻
        # 2020-8-20 10:09:56 Asia/Shanghai ----> 直接把时分秒属性设置为0
        cur_time = timezone.localtime()
        # 2020-8-20 0:0:0 Asia/Shanghai
        cur_0_time = cur_time.replace(hour=0, minute=0, second=0)
        count = User.objects.filter(
            date_joined__gte=cur_0_time
        ).count()

        return Response({
            'count': count,
            'date': cur_time.date()
        })


class UserActiveCountView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        cur_0_time = timezone.localtime().replace(
            hour=0, minute=0, second=0
        )

        count = User.objects.filter(
            last_login__gte=cur_0_time
        ).count()

        return Response({
            'count': count,
            'date': cur_0_time.date()
        })



from orders.models import OrderInfo
class UserOrderCountView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        # 需求：统计当日，下的订单，的用户的数量
        # 1、查询的目标数据：User模型类 —— 用户表(主)
        # 2、已知条件：当日的0时刻 —— 订单表(从)已知条件
        # 规律：依据从表的已知条件，过滤查询出主表的目标数据！

        # 已知条件
        cur_0_time = timezone.localtime().replace(
            hour=0, minute=0, second=0
        )

        # 方案一：从从表入手查询(已知条件是从表)
        # 1、根据从表的已知条件查询得出从表数据
        # orders = OrderInfo.objects.filter(
        #     create_time__gte=cur_0_time
        # )
        # # 2、再根据从表数据，进一步关联查询得出主表数据
        # user_set = set() # 自动去重
        # for order in orders:
        #     # order订单对象
        #     user_set.add(order.user)
        # count = len(user_set)

        # 方案二：从主表入手查询(目标数据是主表)
        order_users = User.objects.filter(
            # 再User过滤中，使用orders的create_time__gte已知条件
            orders__create_time__gte=cur_0_time
        ) # 没有去重

        count = len(set(order_users))


        return Response({
            'count': count,
            'date': cur_0_time.date()
        })


from datetime import timedelta
class UserMonthCountView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        # 需求：统计包含今日在内的最近30天，每一天新建的用户数量
        # 假设某一天的0时刻是calc_0_time,那么这一天新增的用户量
        # User.objects.filter(date_joind__gte=calc_0_time, date_joind__lt=次日的0时刻)

        # 1、当日的0时刻
        # 2020-8-20 0:0:0
        cur_0_time = timezone.localtime().replace(
            hour=0, minute=0, second=0
        )

        end_0_time = cur_0_time
        # 启始日期的0时刻  =  当日的0时刻  -  (统计天数 - 1)天
        # 2020-7-22 0:0:0
        start_0_time = end_0_time - timedelta(days=29)

        # 2、遍历30次，得出每一天的0时刻，过滤那一条的新增用户
        ret_list = []
        for index in range(30):
            # calc_0_time = start_0_time + timedelta(days=0)        index=0
            # calc_0_time = start_0_time + timedelta(days=1)        index=1
            # calc_0_time = start_0_time + timedelta(days=2)        index=2
            # ...
            # calc_0_time = start_0_time + timedelta(days=29)       index=29
            # 其中某一天的0时刻
            calc_0_time = start_0_time + timedelta(days=index)
            count = User.objects.filter(
                date_joined__gte=calc_0_time, # 大于等于当日0时刻
                date_joined__lt=calc_0_time + timedelta(days=1) # 小于次日0时刻
            ).count()

            ret_list.append({
                'count': count,
                'date': calc_0_time.date()
            })

        return Response(ret_list)



from rest_framework.generics import ListAPIView
from meiduo_admin.serializers.home_serializers import *
class GoodsDayView(ListAPIView):
    queryset = GoodsVisitCount.objects.all()
    serializer_class = GoodVistiModelSerializer

    def get_queryset(self):
        """
        重写该函数，实现自定义过滤
        :return: 查询集
        """
        cur_0_time = timezone.localtime().replace(
            hour=0, minute=0, second=0
        )
        # 过滤出今日记录的商品分类访问信息
        return GoodsVisitCount.objects.filter(
            create_time__gte=cur_0_time
        )


















