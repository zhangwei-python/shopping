
from rest_framework.generics import ListAPIView
from rest_framework.viewsets import ModelViewSet
from meiduo_admin.serializers.sku_serializers import *
from meiduo_admin.custom_pagination import MyPage


class SpecSimpleView(ListAPIView):
    queryset = SPUSpecification.objects.all()
    serializer_class = SpecModelSerializer

    def get_queryset(self):
        # 根据请求路径中的pk分组提取参数过滤出关联的规格信息序列化返回
        # 如何在非视图函数中，获取路径参数？
        # 1、路径非命名分组参数，按照传参顺序，封装在self.args中
        # 2、路径泯灭分组参数，以键值对的方式，封装在self.kwargs中
        spu_id = self.kwargs.get('pk')
        return self.queryset.filter(spu_id=spu_id)


class SPUSimpleView(ListAPIView):
    queryset = SPU.objects.all()
    serializer_class = SPUSimpleSerializer


class SKUCateView(ListAPIView):
    queryset = GoodsCategory.objects.all()
    serializer_class = SKUCatSimpleSerialzier

    def get_queryset(self):
        return self.queryset.filter(parent_id__gt=37)


class SKUView(ModelViewSet):
    queryset = SKU.objects.all()
    serializer_class = SKUModelSerializer

    pagination_class = MyPage

    def get_queryset(self):
        keyword = self.request.query_params.get('keyword')
        if keyword:
            return self.queryset.filter(name__contains=keyword)
        return self.queryset.all()