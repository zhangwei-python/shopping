
from rest_framework.generics import ListAPIView,CreateAPIView
from meiduo_admin.serializers.user_serialziers import *
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from meiduo_admin.custom_pagination import MyPage



class UserView(ListAPIView, CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserModelSerializer

    pagination_class = MyPage

    def get_queryset(self):
        # 1、默认返回对象是管理员
        # 2、如果查询字符串中有keyword，根据keyword过滤： self.request.query_params获取查询字符串参数
        keyword = self.request.query_params.get('keyword')
        if keyword:
            return self.queryset.filter(
                username__contains=keyword,
                is_staff=True
            )
        else:
            return self.queryset.filter(is_staff=True)
