
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from rest_framework.decorators import action
from meiduo_admin.serializers.option_serializers import *
from meiduo_admin.custom_pagination import MyPage




class OptionView(ModelViewSet):
    queryset = SpecificationOption.objects.all()
    serializer_class = OptionModelSerializer

    pagination_class = MyPage

    def opt_specs(self, request):
        # 序列化返回可选规格信息
        # 1、获取可选规格的查询集
        specs = SPUSpecification.objects.all()
        # 2、获取序列化器
        s = OptSpecSimpleSerializer(instance=specs, many=True)
        # 3、序列化返回
        return Response(s.data)