

from rest_framework import serializers
from goods.models import GoodsVisitCount

class GoodVistiModelSerializer(serializers.ModelSerializer):
    # 结果是关联对象的主键
    # category = serializers.PrimaryKeyRelatedField()

    # 重写category字段覆盖原有默认映射，类型为StringRelatedField
    # 目的：接口需求该字段序列化的结果必须是分类的名，不是主键
    category = serializers.StringRelatedField()

    class Meta:
        model = GoodsVisitCount
        fields = [
            'category', # 外键关联字段，自动映射为
            'count'
        ]