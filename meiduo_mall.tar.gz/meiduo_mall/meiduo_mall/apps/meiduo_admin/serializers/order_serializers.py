

from rest_framework import serializers
from orders.models import OrderInfo,OrderGoods
from goods.models import SKU

class SKUSimpleModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = SKU
        fields = [
            'name',
            'default_image_url'
        ]


class OrderGoodsModelSerializer(serializers.ModelSerializer):
    # 是单一的SKU模型类对象
    sku = SKUSimpleModelSerializer()

    class Meta:
        model = OrderGoods
        fields = [
            'count',
            'price',
            'sku'
        ]

# OrderInfo详情序列化器
class OrderDetailModelSerializer(serializers.ModelSerializer):
    user = serializers.StringRelatedField()

    # 多个OrderGoods对象序列化
    skus = OrderGoodsModelSerializer(many=True)

    class Meta:
        model = OrderInfo
        fields = "__all__"



class OrderSimpleModelSerializer(serializers.ModelSerializer):
    # 2020/8/22 15:43:56
    # create_time = serializers.DateTimeField(format="%Y/%m/%d %H:%M:%S")

    class Meta:
        model = OrderInfo
        fields = [
            'order_id',
            'create_time'
        ]

        extra_kwargs = {
            'create_time': {'format': '%Y/%m/%d %H:%M:%S'}
        }