

from rest_framework import serializers
from goods.models import SKUImage,SKU


class SKUSimpleModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = SKU
        fields = [
            'id',
            'name'
        ]



class ImageModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = SKUImage
        fields = [
            'id',
            'sku',
            'image' # 序列化器对ImageField类型字段序列化的结果取决于自定义的存储后端！！！
        ]


    # def validate(self, attrs):
        # image: <文件对象> ---> SKUImage(image=<文件对象>) ---> 触发自定义的文件存储后端来实现保存
        # return attrs












