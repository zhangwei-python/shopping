"""
封装工具函数
"""
from django_redis import get_redis_connection
import pickle,base64


# Cookie数据的编码
def carts_cookie_encode(cart_dict):
    """
    把购物车字典数据，经过pickle和base64编码成可视化字符
    :param cart_dict: 购物车字典
    :return: 可视化字符串
    """

    # 1、使用pickle把字段编码成字节
    # 2、base64编码把字节编程成可视化字符
    return base64.b64encode(
        pickle.dumps(cart_dict)
    ).decode()


# Cookie数据解码
def carts_cookie_decode(cart_str):
    """
    把Cookie中的购物车数据(可视化字符串),经过base64解码和pickle解码成字典
    :param cart_str: cookie中的字符串表示的购物车数据
    :return: 购物车字典
    """

    # 1、base解码
    # 2、pickle解码
    return pickle.loads(
        base64.b64decode(cart_str.encode())
    )


# 合并购物车数据
def merge_cart_cookie_to_redis(request, user, response):
    """
    把Cookie购物车数据合并到redis中
    1、如果产生冲突,以cookie为准(商品数量，和选中状态以cookie数据为准)
    2、没有产生冲突,直接把cookie该商品数据直接写入redis
    3、登陆之后，删除cookie
    :param request: 请求对象——读取cookie数据
    :param user: 用户对象——读取redis
    :param response: 视图返回的响应对象——删除cookie数据
    :return: 返回响应对象
    """
    # 1、读取cookie购物车数据
    cart_dict = {} # 初始化孔子点，保存cookie购物数据
    cookie_str = request.COOKIES.get('carts')
    if cookie_str:
        cart_dict = carts_cookie_decode(cookie_str)

    # cart_dict有可能是一个空字典，有可能是购物车数据

    # 2、合并到redis中
    # (1)、sku_id和count添加到redis中
    new_add = cart_dict.keys() # 记录所有需要添加到redis中的sku_id

    # (3)、操作redis购物车
    conn = get_redis_connection('carts')
    for sku_id in new_add:
        # 覆盖写入
        conn.hmset('carts_%s'%user.id, {sku_id:cart_dict[sku_id]['count']})
        # cookie中所有已经选中到商品sku_id加入redis集合，未选中的sku_id从redis集合中删除
        if cart_dict[sku_id]['selected']:
            conn.sadd('selected_%s'%user.id, sku_id)
        else:
            conn.srem('selected_%s'%user.id, sku_id)

    # 3、删除cookie购物车
    response.delete_cookie('carts')
    return response



if __name__ == '__main__':
    # 编写针对当前模块的测试代码
    data = {
        1: {
            'count': 10,
            'selected': True
        },
        2: {
            'count': 2,
            'selected': False
        },
    }

    # 编码
    cart_str = carts_cookie_encode(data)
    print("编码之后的可视化字符串：", cart_str)

    # 解码
    cart_dict = carts_cookie_decode(cart_str)
    print("解码之后的字典数据：", cart_dict, type(cart_dict))







