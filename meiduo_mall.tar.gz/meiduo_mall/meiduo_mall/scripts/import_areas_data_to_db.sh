
mysql -uroot -p12345 -h192.168.203.151 -D meiduo_mall_db < areas.sql
